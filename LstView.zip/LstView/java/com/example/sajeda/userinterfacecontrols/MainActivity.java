package com.example.sajeda.userinterfacecontrols;

import android.app.ListActivity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;

import static android.R.attr.name;

public class MainActivity extends ListActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
       // setContentView(R.layout.activity_main);

        // Array of strings...
        String[] mobileArray = {"Android","IPhone","WindowsMobile","Blackberry",
                "WebOS","Ubuntu","Windows7","Max OS X", "Android List View",
                "Adapter implementation","Simple List View In Android","Create List View Android","Android Example","List View Source Code","List View Array Adapter","Android Example List View" };

        ArrayAdapter<String> adapter=new ArrayAdapter<String>(this,R.layout.activity_listview, mobileArray);
        setListAdapter(adapter);
    }


}
